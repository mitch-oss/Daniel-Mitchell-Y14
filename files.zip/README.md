# Fixit Physio Management System

## 📋 Overview
A comprehensive physiotherapy clinic management system built with Python and CustomTkinter. This system provides role-based access control with separate interfaces for administrators, reception staff, and physiotherapists.

## ✨ Features

### 🔐 Authentication System
- Secure login with hashed passwords (SHA-256)
- Role-based access control (Admin, Staff, Physio)
- Company access key for initial setup

### 👥 User Roles

#### Administrator
- Full system access and control
- User management
- View all appointments and statistics
- System configuration
- Generate reports

#### Reception Staff
- Manage appointments
- Patient registration and management
- View schedules
- Update appointment statuses

#### Physiotherapist
- View personal schedule
- See assigned patients
- Mark appointments as complete
- Access patient medical notes

### 📅 Appointment Management
- Create new appointments
- Assign physiotherapists
- Select from predefined services
- Add custom notes
- Update appointment status (scheduled, completed, cancelled, no-show)
- Filter appointments by date and status
- View statistics

### 👤 Patient Management
- Register new patients
- Store contact information
- Record medical history and notes
- Search patient database
- View patient appointment history

### 💼 Service Management
- Predefined treatment types
- Duration and pricing information
- Service descriptions

## 🚀 Installation & Setup

### Prerequisites
- Python 3.8 or higher
- pip (Python package installer)

### Required Libraries
```bash
pip install customtkinter --break-system-packages
```

### Database Setup
Run the database configuration script first:
```bash
python db_config.py
```

This will:
- Create the SQLite database (`fixit_physio.db`)
- Set up all required tables
- Create default user accounts
- Add sample services
- Set the company access key

## 🔑 Default Login Credentials

### Company Access Key
**Access Key:** `FIXIT2024`

### User Accounts

| Role | Username | Password |
|------|----------|----------|
| Admin | admin | admin123 |
| Staff | staff01 | staff123 |
| Physio | physio01 | physio123 |
| Physio | physio02 | physio123 |

⚠️ **Important:** Change these passwords after first login in a production environment!

## 🎯 How to Run

### Method 1: Start with Login
```bash
python auth_system.py
```

### Method 2: Direct Dashboard Access (Testing)
```bash
# Admin Dashboard
python admin_dashboard.py

# Staff Dashboard  
python staff_dashboard.py

# Physio Dashboard
python physio_dashboard.py
```

## 📁 File Structure

```
fixit_physio/
│
├── db_config.py              # Database setup and initialization
├── auth_system.py            # Login and authentication
│
├── admin_dashboard.py        # Administrator interface
├── staff_dashboard.py        # Reception staff interface
├── physio_dashboard.py       # Physiotherapist interface
│
├── booking_interface.py      # Appointment booking system
├── appointment_system.py     # Appointment viewer and manager
├── patient_manager.py        # Patient registration and management
│
└── fixit_physio.db          # SQLite database (created automatically)
```

## 🗄️ Database Schema

### Tables

#### users
- User accounts with role-based access
- Hashed passwords for security
- Contact information

#### customers (patients)
- Patient personal information
- Contact details
- Medical history and notes

#### appointments
- Booking information
- Links to customers and physiotherapists
- Service details and pricing
- Status tracking

#### services
- Available treatment types
- Duration and pricing
- Descriptions

#### company_access
- Security access keys

## 💡 Usage Guide

### For Administrators

1. **Login** using admin credentials
2. **Dashboard** shows system overview with statistics
3. **Manage Users** - Add/edit staff and physiotherapists
4. **View All Appointments** - See complete schedule
5. **Generate Reports** - Financial and operational analytics
6. **System Settings** - Configure system parameters

### For Reception Staff

1. **Login** using staff credentials
2. **Dashboard** displays today's overview
3. **Book Appointments:**
   - Click "New Booking"
   - Select or add patient
   - Choose service and physiotherapist
   - Set date and time
   - Add notes if needed
   - Confirm booking

4. **Manage Patients:**
   - Add new patients
   - Search existing patients
   - View patient details

5. **View Schedules:**
   - Today's schedule
   - Filter by date/status
   - Update appointment statuses

### For Physiotherapists

1. **Login** using physio credentials
2. **Dashboard** shows your daily schedule
3. **View Appointments:**
   - See assigned patients
   - View appointment details
   - Mark as complete

4. **Patient Information:**
   - Access patient medical notes
   - View treatment history

## 🎨 Color Scheme

- **Primary Blue:** #0066CC - Main brand color
- **Success Green:** #00B894 - Completed actions
- **Warning Orange:** #F39C12 - Pending items
- **Danger Red:** #E17055 - Cancellations/errors
- **Purple:** #9B59B6 - Analytics/statistics

## 🔧 Customization

### Adding New Services
Edit `db_config.py` and add to the `default_services` list:
```python
('Service Name', 'Description', duration_minutes, price)
```

### Adding New Users
Run in Python:
```python
import sqlite3
import hashlib

conn = sqlite3.connect('fixit_physio.db')
cursor = conn.cursor()

password_hash = hashlib.sha256('password123'.encode()).hexdigest()
cursor.execute("""
    INSERT INTO users (username, password_hash, full_name, role, email, phone)
    VALUES (?, ?, ?, ?, ?, ?)
""", ('newuser', password_hash, 'Full Name', 'staff', 'email@example.com', '1234567890'))

conn.commit()
conn.close()
```

### Modifying Company Access Key
Change in `db_config.py` before first run, or update database:
```python
cursor.execute("UPDATE company_access SET access_key = ? WHERE id = 1", ('NEWKEY2024',))
```

## 🐛 Troubleshooting

### Database Issues
If you encounter database errors:
1. Delete `fixit_physio.db`
2. Run `python db_config.py` again

### Import Errors
If modules aren't found:
```bash
pip install customtkinter --break-system-packages
```

### Display Issues
Ensure you're using Python 3.8+ and have Tkinter support:
```bash
python -m tkinter  # Should open a test window
```

## 📝 Notes for WJEC A2 Coursework

### Human-Written Code Features
- Detailed comments explaining each function
- Clear variable names
- Logical code structure
- Educational inline documentation

### Security Features
- Password hashing (SHA-256)
- SQL injection protection (parameterized queries)
- Role-based access control
- Input validation

### Advanced Programming Concepts
- Object-oriented programming (classes)
- Database integration (SQLite)
- GUI development (CustomTkinter)
- Event-driven programming
- Error handling (try-except blocks)

### Extensibility
- Modular file structure
- Easy to add new features
- Clear separation of concerns
- Database-driven configuration

## 📄 License
Educational project for WJEC A2 Computer Science coursework.

## 👨‍💻 Author
Created for Fixit Physio clinic management.

---

**Version:** 1.0  
**Last Updated:** 2024  
**Python Version:** 3.8+
