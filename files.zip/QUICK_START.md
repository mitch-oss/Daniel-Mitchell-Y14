# 🚀 QUICK START GUIDE - Fixit Physio System

## Step 1: Install Required Library
```bash
pip install customtkinter
```

## Step 2: Setup Database (First Time Only)
```bash
python db_config.py
```

You should see:
```
✓ Default users created successfully
✓ Default services created successfully
✓ Company access key set: FIXIT2024
✓ Database setup completed successfully!
```

## Step 3: Run the Application
```bash
python auth_system.py
```

## Step 4: Login

### First Time - Company Access Key
1. Click "🔑 Enter Company Access Key"
2. Enter: `FIXIT2024`
3. Click "Verify Key"

### Login Credentials

**Administrator Account:**
- Username: `admin`
- Password: `admin123`

**Reception Staff Account:**
- Username: `staff01`
- Password: `staff123`

**Physiotherapist Account:**
- Username: `physio01`
- Password: `physio123`

## Step 5: Test the System

### As Admin:
1. Login with admin credentials
2. View dashboard statistics
3. Click "➕ New Booking" to create an appointment
4. Click "👥 Manage Patients" to add a patient

### As Staff:
1. Logout and login with staff01 credentials
2. View today's schedule
3. Add a new patient
4. Book an appointment

### As Physio:
1. Logout and login with physio01 credentials
2. View your assigned appointments
3. Mark appointments as complete

## 📁 File Structure
```
Your_Folder/
├── auth_system.py          ← START HERE (Login screen)
├── db_config.py            ← Run first (Setup database)
├── admin_dashboard.py      ← Admin interface
├── staff_dashboard.py      ← Staff interface
├── physio_dashboard.py     ← Physio interface
├── booking_interface.py    ← Appointment booking
├── appointment_system.py   ← View/manage appointments
├── patient_manager.py      ← Patient management
├── fixit_physio.db        ← Database (auto-created)
└── README.md              ← Full documentation
```

## ⚠️ Troubleshooting

### "Module not found: customtkinter"
```bash
pip install customtkinter
```

### "No database found"
```bash
python db_config.py
```

### "Window opens but crashes"
Make sure you're using Python 3.8 or higher:
```bash
python --version
```

### Reset Everything
1. Delete `fixit_physio.db`
2. Run `python db_config.py` again

## 🎯 Main Features to Show Your Teacher

1. **Role-Based Access Control**
   - Different interfaces for different roles
   - Secure login with hashed passwords

2. **Database Integration**
   - SQLite database
   - Related tables (appointments, customers, users)
   - SQL queries with parameters

3. **Professional UI**
   - Modern, color-coded interface
   - Responsive design
   - Clear navigation

4. **Full CRUD Operations**
   - Create: Add patients, appointments, users
   - Read: View schedules, patient lists
   - Update: Change appointment status
   - Delete: (Can be added if needed)

5. **Input Validation**
   - Date/time format checking
   - Required field validation
   - Error handling

## 💡 Demo Flow for Presentation

1. **Show Login** (auth_system.py)
   - Explain role-based access
   - Show password hashing

2. **Admin Dashboard**
   - Show statistics
   - Navigate through menus
   - Demonstrate user management capability

3. **Book an Appointment**
   - Add a new patient
   - Select service
   - Assign physiotherapist
   - Set date/time

4. **View Appointments**
   - Show filtering options
   - Update appointment status
   - View statistics

5. **Staff Dashboard**
   - Show today's schedule view
   - Demonstrate reception workflows

6. **Physio Dashboard**
   - Show personalized schedule
   - Mark appointments complete

## 📝 Code Highlights for Coursework

Point out these programming concepts:
- **Classes and OOP** (each dashboard is a class)
- **Database operations** (SQL queries)
- **Hash functions** (password security)
- **GUI programming** (CustomTkinter)
- **Error handling** (try-except blocks)
- **Data validation** (input checking)
- **Modular design** (separate files for features)

## ✅ Testing Checklist

- [ ] Database creates successfully
- [ ] Login works with all three roles
- [ ] Can add new patient
- [ ] Can book appointment
- [ ] Can view appointments
- [ ] Can filter appointments
- [ ] Can update appointment status
- [ ] Statistics display correctly
- [ ] Each role sees appropriate menu
- [ ] All buttons work without errors

---

**Need Help?** Check the full README.md for detailed documentation!
